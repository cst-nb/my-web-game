# -*- coding: utf-8 -*-
import pygame
import random
import asyncio

# ── Version ───────────────────────────────────────────────
VERSION = "3.0"

# ── Layout constants ──────────────────────────────────────
WIDTH, HEIGHT      = 500, 650
GRID_SIZE          = 4
TILE_SIZE          = 100
BOARD_OFFSET_X     = 50
BOARD_OFFSET_Y     = 180
MOVE_DURATION      = 0.12
APPEAR_DURATION    = 0.25
SHOCKWAVE_DURATION = 0.5

# ── Colors ────────────────────────────────────────────────
C_RED,    C_GREEN,   C_BLUE    = (192, 57, 43), (30, 80, 40), (41, 128, 185)
C_WHITE                        = (236, 240, 241)
C_YELLOW, C_MAGENTA, C_CYAN    = (241, 196, 15), (142, 68, 173), (26, 188, 156)
C_EMPTY,  C_BG                 = (33, 47, 61), (15, 15, 15)

COLOR_MAP = {
    "RED":     C_RED,     "GREEN":   C_GREEN,
    "BLUE":    C_BLUE,    "WHITE":   C_WHITE,
    "YELLOW":  C_YELLOW,  "MAGENTA": C_MAGENTA,
    "CYAN":    C_CYAN,
}

MIX_RECIPE = {
    tuple(sorted(["RED",     "GREEN"])): "YELLOW",
    tuple(sorted(["RED",     "BLUE" ])): "MAGENTA",
    tuple(sorted(["GREEN",   "BLUE" ])): "CYAN",
    tuple(sorted(["YELLOW",  "BLUE" ])): "WHITE",
    tuple(sorted(["MAGENTA", "GREEN"])): "WHITE",
    tuple(sorted(["CYAN",    "RED"  ])): "WHITE",
}

# ── Render layers ─────────────────────────────────────────
LAYER_BG        = 0
LAYER_SHOCKWAVE = 1
LAYER_PREVIEW   = 2
LAYER_MOVING    = 3
LAYER_MERGED    = 4
LAYER_UI        = 5


class Shockwave:
    def __init__(self, sw_type, index, color):
        self.type  = sw_type   # 'ROW' or 'COL'
        self.index = index
        self.color = color
        self.timer = 0.0
        self.alive = True

    def update(self, dt):
        self.timer += dt
        if self.timer >= SHOCKWAVE_DURATION:
            self.alive = False


class MergeParticle:
    """Small dot that flies from source tile to merge destination."""
    def __init__(self, sx, sy, tx, ty, color):
        self.sx, self.sy = sx, sy
        self.tx, self.ty = tx, ty
        self.color       = color
        self.progress    = 0.0
        self.alive       = True

    def update(self, dt):
        self.progress += dt / 0.18
        if self.progress >= 1.0:
            self.progress = 1.0
            self.alive    = False

    @property
    def pos(self):
        ease = 1 - pow(1 - self.progress, 3)
        return (
            self.sx + (self.tx - self.sx) * ease,
            self.sy + (self.ty - self.sy) * ease,
        )

    @property
    def alpha(self):
        return int(255 * (1 - self.progress))


class Tile:
    def __init__(self, color=None, wolf=False, bomb=False, is_new=False):
        self.color           = color
        self.wolf            = wolf
        self.bomb            = bomb
        self.x,      self.y  = 0, 0
        self.start_x,  self.start_y  = 0, 0
        self.target_x, self.target_y = 0, 0
        self.move_progress   = 1.0
        self.appear_progress = 0.0 if is_new else 1.0
        self.is_new          = is_new
        self.layer           = LAYER_MOVING

    @property
    def scale(self):
        """Elastic overshoot scale: 0 -> 1.3 -> 1.0"""
        if self.appear_progress >= 1.0:
            return 1.0
        p         = self.appear_progress
        overshoot = 1.3
        if p < 0.7:
            return (p / 0.7) * overshoot
        t = (p - 0.7) / 0.3
        return overshoot + (1.0 - overshoot) * t


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(f"Alchemy Strategy v{VERSION}")
        self.clock = pygame.time.Clock()

        # Font loading with fallback for pygbag/Wasm environments
        try:
            self.font     = pygame.font.SysFont("Arial", 18, bold=True)
            self.big_font = pygame.font.SysFont("Arial", 36, bold=True)
        except Exception:
            self.font     = pygame.font.Font(None, 22)
            self.big_font = pygame.font.Font(None, 44)

        # Swipe threshold in normalized coords (0~1); 0.04 approx 40px on mobile
        self.finger_start_pos = None
        self.swipe_threshold  = 0.04

        self.shockwaves      = []
        self.merge_particles = []
        self.reset_game()

    # ── Init / Reset ──────────────────────────────────────
    def reset_game(self):
        self.grid         = [[None] * GRID_SIZE for _ in range(GRID_SIZE)]
        self.score        = 0
        self.animating    = False
        self.game_over    = False
        self.elapsed_time = 0
        self.shockwaves.clear()
        self.merge_particles.clear()
        self.spawn_initial()

    def get_pixel(self, r, c):
        return (BOARD_OFFSET_X + c * TILE_SIZE + 5,
                BOARD_OFFSET_Y + r * TILE_SIZE + 5)

    # ── Tile spawning ─────────────────────────────────────
    def spawn_tile(self, count=1):
        empty = [(r, c) for r in range(GRID_SIZE)
                 for c in range(GRID_SIZE) if self.grid[r][c] is None]
        num_tiles = sum(1 for row in self.grid for t in row if t)
        for _ in range(min(count, len(empty))):
            r, c = random.choice(empty)
            empty.remove((r, c))
            base_prob = 0.06 if num_tiles >= 12 else 0.03
            if self.score > 200 and random.random() < base_prob:
                tile = Tile(bomb=True, is_new=True)
            else:
                color = random.choice(["RED", "GREEN", "BLUE"])
                tile  = Tile(color=color, wolf=(random.random() < 0.25), is_new=True)
            tile.x, tile.y               = self.get_pixel(r, c)
            tile.target_x, tile.target_y = tile.x, tile.y
            tile.layer                   = LAYER_MOVING
            self.grid[r][c]              = tile

    def spawn_initial(self):
        self.spawn_tile(6)

    # ── Move handling ─────────────────────────────────────
    def handle_move(self, direction):
        if self.animating or self.game_over:
            return
        old_state    = [[(t.color, t.wolf, t.bomb) if t else None for t in row]
                        for row in self.grid]
        border_map   = {"LEFT": "RED", "RIGHT": "BLUE",
                        "UP": "GREEN", "DOWN": "WHITE"}
        target_color    = border_map[direction]
        triggered_bombs = []

        for i in range(GRID_SIZE):
            if direction in ("LEFT", "RIGHT"):
                line = self.grid[i][:]
                if direction == "RIGHT":
                    line.reverse()
                tiles = [t for t in line if t is not None]
                if tiles and tiles[0].bomb:
                    triggered_bombs.append(("ROW", i))
                    self.shockwaves.append(Shockwave("ROW", i, COLOR_MAP[target_color]))
                new_line = self.process_logic(line, target_color)
                if direction == "RIGHT":
                    new_line.reverse()
                self.grid[i] = new_line
            else:
                line = [self.grid[r][i] for r in range(GRID_SIZE)]
                if direction == "DOWN":
                    line.reverse()
                tiles = [t for t in line if t is not None]
                if tiles and tiles[0].bomb:
                    triggered_bombs.append(("COL", i))
                    self.shockwaves.append(Shockwave("COL", i, COLOR_MAP[target_color]))
                new_line = self.process_logic(line, target_color)
                if direction == "DOWN":
                    new_line.reverse()
                for r in range(GRID_SIZE):
                    self.grid[r][i] = new_line[r]

        for b_type, idx in triggered_bombs:
            if b_type == "ROW":
                for c in range(GRID_SIZE): self.grid[idx][c] = None
            else:
                for r in range(GRID_SIZE): self.grid[r][idx] = None
            self.score += 80

        new_state = [[(t.color, t.wolf, t.bomb) if t else None for t in row]
                     for row in self.grid]
        if new_state != old_state:
            self.prepare_animation()
            self.animating = True
            self.spawn_tile(random.randint(1, 2))
        elif sum(1 for row in self.grid for t in row if t) == GRID_SIZE * GRID_SIZE:
            self.game_over = True

    def process_logic(self, line, border_color):
        tiles = [t for t in line if t is not None]
        if not tiles:
            return [None] * GRID_SIZE
        if tiles[0].bomb:
            return [None] * GRID_SIZE

        match_count = 0
        if tiles[0].color == border_color:
            for t in tiles:
                if t.color == border_color:
                    match_count += 1
                    self.score += 100 if t.color == "WHITE" else 20
                else:
                    break

        remaining = tiles[match_count:]
        new_tiles = []
        idx = 0
        while idx < len(remaining):
            curr = remaining[idx]
            if idx + 1 < len(remaining):
                hunter = remaining[idx + 1]
                if hunter.wolf and not curr.wolf and not curr.bomb:
                    recipe = tuple(sorted([hunter.color, curr.color]))
                    if recipe in MIX_RECIPE:
                        res    = MIX_RECIPE[recipe]
                        merged = Tile(color=res, wolf=(res != "WHITE"), is_new=True)
                        merged.layer = LAYER_MERGED
                        dest_cx = curr.x + 45
                        dest_cy = curr.y + 45
                        self.merge_particles.append(
                            MergeParticle(curr.x + 45, curr.y + 45,
                                          dest_cx, dest_cy, COLOR_MAP[curr.color]))
                        self.merge_particles.append(
                            MergeParticle(hunter.x + 45, hunter.y + 45,
                                          dest_cx, dest_cy, COLOR_MAP[hunter.color]))
                        new_tiles.append(merged)
                        idx += 2
                        continue
            new_tiles.append(curr)
            idx += 1

        return ([None] * match_count
                + new_tiles
                + [None] * (GRID_SIZE - match_count - len(new_tiles)))

    # ── Animation ─────────────────────────────────────────
    def prepare_animation(self):
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                t = self.grid[r][c]
                if t:
                    t.start_x, t.start_y   = t.x, t.y
                    t.target_x, t.target_y = self.get_pixel(r, c)
                    t.move_progress        = 0

    def update(self, dt):
        self.shockwaves = [sw for sw in self.shockwaves if sw.alive]
        for sw in self.shockwaves:
            sw.update(dt)
        self.shockwaves = [sw for sw in self.shockwaves if sw.alive]

        self.merge_particles = [mp for mp in self.merge_particles if mp.alive]
        for mp in self.merge_particles:
            mp.update(dt)
        self.merge_particles = [mp for mp in self.merge_particles if mp.alive]

        done = True
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                t = self.grid[r][c]
                if not t:
                    continue
                if t.move_progress < 1:
                    t.move_progress += dt / MOVE_DURATION
                    p    = min(1.0, t.move_progress)
                    ease = 1 - pow(1 - p, 3)
                    t.x  = t.start_x + (t.target_x - t.start_x) * ease
                    t.y  = t.start_y + (t.target_y - t.start_y) * ease
                    if t.move_progress < 1:
                        done = False
                if t.is_new and t.appear_progress < 1.0:
                    t.appear_progress += dt / APPEAR_DURATION
                    if t.appear_progress >= 1.0:
                        t.appear_progress = 1.0
                        t.is_new          = False
                        t.layer           = LAYER_MOVING
        if done:
            self.animating = False

    # ── Draw helpers ──────────────────────────────────────
    def draw_tile(self, t):
        s         = t.scale
        base_size = TILE_SIZE - 10
        draw_size = int(base_size * s)
        if draw_size <= 0:
            return
        cx     = int(t.x + base_size / 2)
        cy     = int(t.y + base_size / 2)
        rect   = (cx - draw_size // 2, cy - draw_size // 2, draw_size, draw_size)
        radius = max(2, int(10 * s))

        if t.bomb:
            pygame.draw.rect(self.screen, (50, 50, 50), rect, border_radius=radius)
            pygame.draw.circle(self.screen, (230, 126, 34), (cx, cy), int(22 * s), 3)
        else:
            pygame.draw.rect(self.screen, COLOR_MAP[t.color], rect, border_radius=radius)
            if t.wolf:
                pygame.draw.circle(self.screen, (0, 0, 0),       (cx, cy), int(14 * s))
                pygame.draw.circle(self.screen, (255, 255, 255), (cx, cy), int(8  * s))

        if t.layer == LAYER_MERGED and t.is_new:
            glow_alpha = int(80 * (1 - t.appear_progress))
            glow_r     = int((base_size // 2 + 8) * s)
            if glow_r > 0 and glow_alpha > 0:
                glow_surf = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)
                pygame.draw.circle(glow_surf, (*COLOR_MAP[t.color], glow_alpha),
                                   (glow_r, glow_r), glow_r)
                self.screen.blit(glow_surf, (cx - glow_r, cy - glow_r))

    def draw_shockwaves(self):
        for sw in self.shockwaves:
            progress          = sw.timer / SHOCKWAVE_DURATION
            alpha             = int(255 * (1 - pow(progress, 2)))
            surf              = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            shrink_factor     = 1 - progress * 0.5
            current_thickness = (TILE_SIZE - 10) * shrink_factor
            offset            = ((TILE_SIZE - 10) - current_thickness) / 2
            color_a           = (*sw.color, alpha)
            core_alpha        = min(255, alpha + 40)

            if sw.type == "ROW":
                py   = BOARD_OFFSET_Y + sw.index * TILE_SIZE + 5 + offset
                rect = (BOARD_OFFSET_X, py, GRID_SIZE * TILE_SIZE, current_thickness)
                pygame.draw.rect(surf, color_a, rect,
                                 border_radius=int(5 * shrink_factor))
                pygame.draw.line(surf, (*sw.color, core_alpha),
                                 (BOARD_OFFSET_X, py + current_thickness / 2),
                                 (BOARD_OFFSET_X + GRID_SIZE * TILE_SIZE,
                                  py + current_thickness / 2), 2)
            else:
                px   = BOARD_OFFSET_X + sw.index * TILE_SIZE + 5 + offset
                rect = (px, BOARD_OFFSET_Y, current_thickness, GRID_SIZE * TILE_SIZE)
                pygame.draw.rect(surf, color_a, rect,
                                 border_radius=int(5 * shrink_factor))
                pygame.draw.line(surf, (*sw.color, core_alpha),
                                 (px + current_thickness / 2, BOARD_OFFSET_Y),
                                 (px + current_thickness / 2,
                                  BOARD_OFFSET_Y + GRID_SIZE * TILE_SIZE), 2)
            self.screen.blit(surf, (0, 0))

    def draw_merge_particles(self):
        surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for mp in self.merge_particles:
            px, py = mp.pos
            r      = max(1, int(7 * (1 - mp.progress * 0.5)))
            pygame.draw.circle(surf, (*mp.color, mp.alpha), (int(px), int(py)), r)
        self.screen.blit(surf, (0, 0))

    # ── Main draw ─────────────────────────────────────────
    def draw(self):
        self.screen.fill(C_BG)

        # Recipe guide row 1: basic mixing
        guide_x_start = 45
        base_y        = 30
        for i, (c1, c2, res) in enumerate([
                ("RED", "GREEN", "YELLOW"),
                ("RED", "BLUE",  "MAGENTA"),
                ("GREEN", "BLUE", "CYAN")]):
            x = guide_x_start + i * 145
            pygame.draw.circle(self.screen, COLOR_MAP[c1],  (x,      base_y), 8)
            pygame.draw.circle(self.screen, COLOR_MAP[c2],  (x + 20, base_y), 8)
            self.screen.blit(self.font.render("=", True, (150, 150, 150)),
                             (x + 35, base_y - 12))
            pygame.draw.circle(self.screen, COLOR_MAP[res], (x + 60, base_y), 10)

        # Recipe guide row 2: advanced mixing -> WHITE
        base_y_2 = 75
        for i, (c1, c2) in enumerate([
                ("YELLOW",  "BLUE"),
                ("MAGENTA", "GREEN"),
                ("CYAN",    "RED")]):
            x = guide_x_start + i * 145
            pygame.draw.circle(self.screen, COLOR_MAP[c1],     (x,      base_y_2), 10)
            pygame.draw.circle(self.screen, COLOR_MAP[c2],     (x + 22, base_y_2), 8)
            self.screen.blit(self.font.render("=", True, (150, 150, 150)),
                             (x + 40, base_y_2 - 12))
            pygame.draw.circle(self.screen, COLOR_MAP["WHITE"], (x + 65, base_y_2), 11)
            pygame.draw.circle(self.screen, (0, 0, 0),          (x + 65, base_y_2), 11, 1)

        # Direction color borders
        pygame.draw.rect(self.screen, C_RED,   (40,  BOARD_OFFSET_Y,        6,   400))
        pygame.draw.rect(self.screen, C_BLUE,  (454, BOARD_OFFSET_Y,        6,   400))
        pygame.draw.rect(self.screen, C_GREEN, (50,  BOARD_OFFSET_Y - 10,  400,    6))
        pygame.draw.rect(self.screen, C_WHITE, (50,  BOARD_OFFSET_Y + 404, 400,    6))

        # Empty cell slots
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                bx, by = self.get_pixel(r, c)
                pygame.draw.rect(self.screen, C_EMPTY,
                                 (bx, by, TILE_SIZE - 10, TILE_SIZE - 10),
                                 border_radius=8)

        self.draw_shockwaves()

        # Wolf tile merge preview lines
        if not self.animating:
            for r in range(GRID_SIZE):
                for c in range(GRID_SIZE):
                    curr = self.grid[r][c]
                    if curr and curr.wolf:
                        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                            nr, nc = r + dr, c + dc
                            if 0 <= nr < GRID_SIZE and 0 <= nc < GRID_SIZE:
                                target = self.grid[nr][nc]
                                if target and not target.wolf and not target.bomb:
                                    recipe = tuple(sorted([curr.color, target.color]))
                                    if recipe in MIX_RECIPE:
                                        res_color = COLOR_MAP[MIX_RECIPE[recipe]]
                                        pygame.draw.line(
                                            self.screen, res_color,
                                            (int(curr.x + 45), int(curr.y + 45)),
                                            (int(target.x + 45), int(target.y + 45)), 2)

        # Draw LAYER_MOVING tiles
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                t = self.grid[r][c]
                if t and t.layer == LAYER_MOVING:
                    self.draw_tile(t)

        self.draw_merge_particles()

        # Draw LAYER_MERGED tiles (on top of particles)
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                t = self.grid[r][c]
                if t and t.layer == LAYER_MERGED:
                    self.draw_tile(t)

        # UI text
        self.screen.blit(
            self.big_font.render(f"SCORE: {self.score}", True, (255, 255, 255)),
            (50, 125))
        self.screen.blit(
            self.font.render("Swipe or Arrows to Play / R to Reset",
                             True, (100, 120, 140)),
            (50, HEIGHT - 35))

        # Game over overlay
        if self.game_over:
            overlay = pygame.Surface((WIDTH, HEIGHT))
            overlay.set_alpha(210)
            overlay.fill((0, 0, 0))
            self.screen.blit(overlay, (0, 0))
            pygame.draw.rect(self.screen, (44, 62, 80),
                             (100, 260, 300, 180), border_radius=15)
            t1 = self.big_font.render("GAME OVER",               True, (236, 240, 241))
            t2 = self.font.render(f"Final Score: {self.score}",  True, (241, 196, 15))
            t3 = self.font.render("Tap or Press 'R' to Restart", True, (200, 200, 200))
            cx = WIDTH // 2
            self.screen.blit(t1, (cx - t1.get_width() // 2, 290))
            self.screen.blit(t2, (cx - t2.get_width() // 2, 345))
            self.screen.blit(t3, (cx - t3.get_width() // 2, 385))

        pygame.display.flip()

    # ── Main loop (asyncio required by pygbag) ────────────
    async def run(self):
        while True:
            dt = self.clock.tick(60) / 1000.0

            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    pygame.quit()
                    return

                # Keyboard
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_r and self.game_over:
                        self.reset_game()
                    elif not self.game_over:
                        key_map = {
                            pygame.K_LEFT:  "LEFT",
                            pygame.K_RIGHT: "RIGHT",
                            pygame.K_UP:    "UP",
                            pygame.K_DOWN:  "DOWN",
                        }
                        if e.key in key_map:
                            self.handle_move(key_map[e.key])

                # Touch
                elif e.type == pygame.FINGERDOWN:
                    self.finger_start_pos = (e.x, e.y)

                elif e.type == pygame.FINGERUP:
                    if self.game_over:
                        self.reset_game()
                    elif self.finger_start_pos and not self.animating:
                        dx = e.x - self.finger_start_pos[0]
                        dy = e.y - self.finger_start_pos[1]
                        if abs(dx) > self.swipe_threshold or abs(dy) > self.swipe_threshold:
                            if abs(dx) > abs(dy):
                                self.handle_move("RIGHT" if dx > 0 else "LEFT")
                            else:
                                self.handle_move("DOWN" if dy > 0 else "UP")
                    self.finger_start_pos = None

                # Mouse click fallback for desktop/browser
                elif e.type == pygame.MOUSEBUTTONDOWN:
                    if self.game_over:
                        self.reset_game()

            self.update(dt)
            self.draw()
            await asyncio.sleep(0)   # Required by pygbag: yield to browser event loop


if __name__ == "__main__":
    game = Game()
    asyncio.run(game.run())